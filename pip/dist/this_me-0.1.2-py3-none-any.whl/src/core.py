class Me:
    def __init__(self, name="suiGn"):
        self.name = name

    def __repr__(self):
        return f"<this.me {self.name}>"